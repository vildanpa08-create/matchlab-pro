MATCHLAB PRO V2
Python 3.10+ kurun. Klasörde terminal açın:
python -m pip install -r requirements.txt
python -m streamlit run app.py
Tarayıcı: http://localhost:8501
Telefon: aynı Wi-Fi ağında bilgisayarın yerel IP adresi ve 8501 portu (güvenlik duvarı izin verirse). İnternetten erişim için ayrıca güvenli hosting gerekir.
CSV: date,home,away,oh,od,oa,hg,ag; isteğe bağlı ht_h,ht_a,book. Tek bahis bürosu ve tek oran zamanı içeren dosya kullanın. Stake otomatik çekilmez. Kaynak kod mevcut sezon dosyalarını fd_cache klasöründe saklar; güncellemek için ilgili dosyayı silin.
